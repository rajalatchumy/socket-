package Server;

import java.io.*;
import java.net.*;

public class FileServer {
    public static void main(String[] args) {
        int port = 5555; // port number
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is waiting for incoming connections...");

            while (true) {
                // Accept a client connection
                Socket clientSocket = serverSocket.accept();

                // Create a new thread to handle each client
                Thread clientRequest = new ClientRequest(clientSocket);
                clientRequest.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
